package unsw.venues;

import java.time.LocalDate;

import java.util.ArrayList;



import org.json.JSONArray;

import org.json.JSONObject;

public class Venue {

	private String name;
	private ArrayList<Room> rooms; // list of rooms
	public Venue(String name) {
		
		this.name = name;
		this.rooms = new ArrayList<Room>();
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @return the rooms
	 */
	public ArrayList<Room> getRooms() {
		return rooms;
	}
	
	public void addRoom (String roomName, String size) {
		Room newRoom = new Room (roomName, size, name);
		rooms.add(newRoom);
	}
	
	public Booking requestBooking (String id, String size, LocalDate startDate, LocalDate endDate ) {
		for (Room room : rooms) {
			//Booking newBooking = room.makeBooking(id, startDate, endDate, size);
			if (room.getSize().equals(size)) {
				Booking newBooking = room.makeBooking(id, startDate, endDate, size);
				if (newBooking != null) {
					return newBooking;
				}
			}
		}
		return null;
	}
	
	// for change
	public void insertBooking (Booking booking) {
		for (Room room : rooms) {
			if (room.getName().equals(booking.getRoomName())) {
				room.addBooking(booking);
				return;
			}
		}
	}
	
	public JSONArray getVenueBookingList() {

		JSONArray venueBookingList = new JSONArray();

		for(Room room : this.rooms) {

			JSONObject roomDetail = new JSONObject();
			roomDetail.put("room", room.getName());
			roomDetail.put("reservations",room.getBookingList());
			venueBookingList.put(roomDetail);
			
		}

		return venueBookingList;

	}
	
	
	
}
