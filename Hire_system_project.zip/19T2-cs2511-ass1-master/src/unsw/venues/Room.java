/**
 * 
 */
package unsw.venues;

import java.time.LocalDate;

import java.util.ArrayList;



import org.json.JSONArray;

import org.json.JSONObject;


public class Room {

	private String name;
	private String size;
	private String hostVenue;
	private ArrayList<Booking> bookings;
	/**
	 * 
	 */
	
	public Room(String name, String size, String hostVenue) {
		super();
		this.name = name;
		this.size = size;
		this.hostVenue = hostVenue;
		this.bookings = new ArrayList<Booking>();
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the size
	 */
	public String getSize() {
		return size;
	}

	/**
	 * @return the bookings
	 */
	public ArrayList<Booking> getBookings() {
		return bookings;
	}
	
	// check if the date is available for booking
	public boolean checkAvailable (LocalDate startDate, LocalDate endDate) {
		boolean available = true;
		for (Booking booking : bookings) {
			if (startDate.isAfter(booking.getEndDate()) || endDate.isBefore(booking.getStartDate())) {
				available = true;
			}
			else {
				available = false;
				break;
			}
		}
		return available;
	}
	public Booking makeBooking (String id, LocalDate startDate, LocalDate endDate, String size) {
		
		if (checkAvailable(startDate, endDate) == true) {
			Booking booking = new Booking (id, name, hostVenue, startDate, endDate);
			addBooking(booking);
			return booking;
		}
		return null;
			
		
	}
	
	// add new booking to the bookings list
	public void addBooking (Booking booking) {
		for (int i = 0 ; i < bookings.size(); i++) {
			if (checkListOrder(booking, i)){
				continue;
			}
			else {
				bookings.add(i, booking);
				return;
			}
		
		}
		bookings.add(booking);
	}
	public boolean checkListOrder(Booking booking, int i) {
		boolean isAfter = false;
		if (booking.getStartDate().isAfter(bookings.get(i).getStartDate()) == true) {
			isAfter = true;
		}
		return isAfter;
	}
				
	// for change and cancel
	public Booking modifyBooking (String id) {
		for (Booking booking : bookings) {
			if (id.equals(booking.getId()) == true) {
				Booking modified = booking;
				bookings.remove(modified);
				return modified;
			}
		}
		return null;
	}
	
	
	
	public JSONArray getBookingList() {

		JSONArray bookingList = new JSONArray();

		for(Booking booking : bookings) {

			bookingList.put(booking.getBookingDetails());

		}

		return bookingList;

	}

}
