/**
 *
 */
package unsw.venues;

import java.time.LocalDate;
import java.util.Scanner;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Venue Hire System for COMP2511.
 *
 * A basic prototype to serve as the "back-end" of a venue hire system. Input
 * and output is in JSON format.
 *
 * @author
 *
 */
public class VenueHireSystem {

    /**
     * Constructs a venue hire system. Initially, the system contains no venues,
     * rooms, or bookings.
     */
	private ArrayList<Venue> venues;
	private ArrayList<String> ids;
    public VenueHireSystem() {
        // TODO Auto-generated constructor stub
    	this.venues = new ArrayList<Venue>();
    	this.ids = new ArrayList<String>();
    }

    private void processCommand(JSONObject json) {
        switch (json.getString("command")) {

        case "room":
            String venue = json.getString("venue");
            String room = json.getString("room");
            String size = json.getString("size");
            addRoom(venue, room, size);
            
            break;

        case "request":
            String id = json.getString("id");
            LocalDate start = LocalDate.parse(json.getString("start"));
            LocalDate end = LocalDate.parse(json.getString("end"));
            int small = json.getInt("small");
            int medium = json.getInt("medium");
            int large = json.getInt("large");

            JSONObject result = request(id, start, end, small, medium, large);

            System.out.println(result.toString());
            
            break;
           

        // TODO Implement other commands
        case "change":
            String id_ch = json.getString("id");
            LocalDate start_ch = LocalDate.parse(json.getString("start"));
            LocalDate end_ch = LocalDate.parse(json.getString("end"));
            int small_ch = json.getInt("small");
            int medium_ch = json.getInt("medium");
            int large_ch = json.getInt("large");

            JSONObject result_ch = change(id_ch, start_ch, end_ch, small_ch, medium_ch, large_ch);

            System.out.println(result_ch.toString());
            
            break;    
        case "cancel":
            String id_c = json.getString("id");
            

            JSONObject result_c = cancel(id_c);

            System.out.println(result_c.toString());
            
            break;
       
        case "list":
        	
        	String venue_l = json.getString("venue");
        	JSONArray list_l = list(venue_l);
        	System.out.println(list_l.toString(2));
        	
        	break;
        
        }
    }

    private void addRoom(String venue, String room, String size) {
        // TODO Process the room command
    	boolean exist = false;
    	for (Venue v : venues) {
    		if (venue.equals(v.getName())) {
    			exist = true;
    			v.addRoom(room, size);
    			return;
    		}
    	}
    	if (exist == false) {
    		Venue newVenue = new Venue(venue);
    		venues.add(newVenue);
    		newVenue.addRoom(room, size);
    	}
    }

    public JSONObject request(String id, LocalDate start, LocalDate end,
            int small, int medium, int large) {
        JSONObject result = new JSONObject();

        // TODO Process the request commmand
        ArrayList<Booking> bookingList = new ArrayList<Booking>();
        for (Venue venue : venues) {
        	boolean venueAva = true;
        	boolean s = checkAva(id, start, end, venue, "small", small, bookingList);
        	boolean m = checkAva(id, start, end, venue, "medium", medium, bookingList);
        	boolean l = checkAva(id, start, end, venue, "large", large, bookingList);
        	if (!s || !m || !l) {
        		venueAva = false;
        	}
        	if (venueAva == true) {
        		//System.out.println("hello");
        		result.put("status", "success");
        		result.put("venue", venue.getName());
        		
        		JSONArray rooms = new JSONArray();
        		for (Booking booking : bookingList) {
        			rooms.put(booking.getRoomName());
        			
        		}
        		result.put("rooms", rooms);
        		ids.add(id);
        		return result;
        	} else {
        		for (Room room : venue.getRooms()) {
        			room.modifyBooking(id);  
        		}
        		bookingList.clear();
        		//venueAva = true;
        	}
        }
        result.put("status", "rejected");
        
        return result;
      }
    
    public boolean checkAva(String id, LocalDate start, LocalDate end, Venue v, String size,int num,ArrayList<Booking> bookingList) {
    	boolean roomAva = true;
    	for (int i = 0;i < num;i++) {
    		Booking newBooking = v.requestBooking(id, size, start, end);
    		if (newBooking == null) {
    			roomAva = false;
    			break;
    		} else {
    			bookingList.add(newBooking);
    		}
    	}
    	return roomAva;
    }
    
    
    public JSONObject change(String id, LocalDate start, LocalDate end,
    		int small, int medium, int large) {

    	JSONObject result = new JSONObject();
    	if (!ids.contains(id)) {
    		result.put("status", "rejected");
    		return result;
    	}

    	ArrayList<Booking> tem = new ArrayList<Booking>();

    	for(Venue venue: venues) {
    		for(Room room : venue.getRooms()) {
    			Booking bookingTochange = room.modifyBooking(id);
    			if(bookingTochange != null) {
    				tem.add(bookingTochange);
    			} else {
    				continue;
    			}
    		}
    	}
    	ids.remove(id);

    	JSONObject temp = this.request(id, start, end, small, medium, large);
    	if (temp.getString("status").equals("rejected")) {
    		for(Booking booking : tem) {
    			for(Venue venue: venues) {
    				if(booking.getHostVenue().equals(venue.getName())) {
    					for(Room room: venue.getRooms()) {
    						if(booking.getRoomName().equals(room.getName())) {
    							room.addBooking(booking);
    						} else {
    							continue;
    						}   				
    					}
    				} else {
    					continue;
    				}    		
    			}
    		}
    		ids.add(id);
    	}
    	return temp;
    }
    
    
    public JSONObject cancel(String id) {
    	JSONObject result = new JSONObject();
    	if (ids.contains(id) == false) {
    		result.put("ststus", "rejected");
    		return result;
    	}
    	for (Venue venue :venues) {
    		for (Room room : venue.getRooms()) {    			
    			room.modifyBooking(id);  		
    		}
    	}
    	result.put("status", "success");
    	return result;
    }
    
    public JSONArray list(String venue) {
    	
    	JSONArray result = new JSONArray();
    	for (Venue v:venues) {
    		if(venue.equals(v.getName())) {
    			return v.getVenueBookingList();
    		}
    	}
    	return result;
    }
    
    
    
    

    public static void main(String[] args) {
        VenueHireSystem system = new VenueHireSystem();

        Scanner sc = new Scanner(System.in);

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            if (!line.trim().equals("")) {
                JSONObject command = new JSONObject(line);
                system.processCommand(command);
            }
        }
        sc.close();
    }

}
