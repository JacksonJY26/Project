package unsw.venues;

import java.time.LocalDate;

import org.json.JSONObject;


public class Booking {
	
	private String id;
	private String roomName;
	private String hostVenue; // Venue name
	private LocalDate startDate;
	private LocalDate endDate;
	
	public Booking(String id, String roomName, String hostVenue, LocalDate startDate, LocalDate endDate) {
		this.id = id;
		this.roomName = roomName;
		this.hostVenue = hostVenue;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return the roomName
	 */
	public String getRoomName() {
		return roomName;
	}

	/**
	 * @return the hostVenue
	 */
	public String getHostVenue() {
		return hostVenue;
	}

	/**
	 * @return the startDate
	 */
	public LocalDate getStartDate() {
		return startDate;
	}

	/**
	 * @return the endDate
	 */
	public LocalDate getEndDate() {
		return endDate;
	}
	
	public JSONObject getBookingDetails() {
		
		JSONObject detail = new JSONObject();

		detail.put("id", id);

		detail.put("start", startDate.toString());

		detail.put("end", endDate.toString());

		return detail;

	}

	
	









}
