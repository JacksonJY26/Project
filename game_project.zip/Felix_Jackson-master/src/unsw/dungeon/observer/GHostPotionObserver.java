package unsw.dungeon.observer;

import unsw.dungeon.domain.Player;

public class GHostPotionObserver implements Observer
{
    private Player player;

    public GHostPotionObserver(Player player) {
        this.player = player;
        this.player.addObserver(this);
    }

    @Override
    public void update() {
        System.out.println("get the invincibility potion, start timer");
        player.getgHostPotion().startTimer();
    }
}
