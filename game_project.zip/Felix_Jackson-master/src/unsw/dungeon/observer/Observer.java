package unsw.dungeon.observer;

public interface Observer {

    public abstract void update();

}
