package unsw.dungeon.domain;

public class Exit extends Entity{
    /**
     * Create an entity positioned in square (x,y)
     *
     * @param x
     * @param y
     */
    public Exit(int x, int y) {
        super(x, y);
    }
}
