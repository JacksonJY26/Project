package unsw.dungeon.domain;

import unsw.dungeon.util.DungeonUtil;

public class Hound extends Enemy{

    public Hound(Dungeon dungeon, int x, int y) {
        super(dungeon, x, y);
        this.dungeon = dungeon;
    }

    private Dungeon dungeon;

    public Dungeon getDungeon() {
        return dungeon;
    }

    public void setDungeon(Dungeon dungeon) {
        this.dungeon = dungeon;
    }

    @Override
    public void moveAutomatic() {
        double tmpDistance = Double.MAX_VALUE;
        String tmpOrient = "";
        if (calculateDistance(getX(), getY()) == 0) {
            return;
        }
        if (!DungeonUtil.getNode(getX() - 1, getY(), dungeon).equals("Wall")) {
            if (calculateDistance(getX() - 1, getY()) < tmpDistance) {
                tmpOrient = "Left";
                tmpDistance = calculateDistance(getX() - 1, getY());
            }
        }
        if (!DungeonUtil.getNode(getX() + 1, getY(), dungeon).equals("Wall")) {
            if (calculateDistance(getX() + 1, getY()) < tmpDistance) {
                tmpOrient = "Right";
                tmpDistance = calculateDistance(getX() + 1, getY());
            }
        }
        if (!DungeonUtil.getNode(getX(), getY() - 1, dungeon).equals("Wall")) {
            if (calculateDistance(getX(), getY() - 1) < tmpDistance) {
                tmpOrient = "Up";
                tmpDistance = calculateDistance(getX(), getY() - 1);
            }
        }
        if (!DungeonUtil.getNode(getX(), getY() + 1, dungeon).equals("Wall")) {
            if (calculateDistance(getX(), getY() + 1) < tmpDistance) {
                tmpOrient = "Down";
                tmpDistance = calculateDistance(getX(), getY() + 1);
            }
        }
        moveNextStop(tmpOrient);
    }
}
