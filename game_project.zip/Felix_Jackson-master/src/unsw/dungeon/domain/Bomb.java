package unsw.dungeon.domain;

public class Bomb extends Entity {
    /**
     * Create an entity positioned in square (x,y)
     *
     * @param x
     * @param y
     */

    private int lastTime = 5;


    public int getLastTime() {
        return lastTime;
    }

    public void setLastTime(int lastTime) {
        this.lastTime = lastTime;
    }

    public Bomb(int x, int y) {
        super(x, y);
    }


}
