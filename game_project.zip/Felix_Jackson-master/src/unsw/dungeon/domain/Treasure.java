package unsw.dungeon.domain;

public class Treasure extends Entity {
    /**
     * Create an entity positioned in square (x,y)
     *
     * @param x
     * @param y
     */
    public Treasure(int x, int y) {
        super(x, y);
    }
}
