package unsw.dungeon.domain;

public class Switch extends Entity {
    /**
     * Create an entity positioned in square (x,y)
     *
     * @param x
     * @param y
     */
    public Switch(int x, int y) {
        super(x, y);
    }
}
