package unsw.dungeon.domain;

public class Wall extends Entity {

    public Wall(int x, int y) {
        super(x, y);
    }

}
