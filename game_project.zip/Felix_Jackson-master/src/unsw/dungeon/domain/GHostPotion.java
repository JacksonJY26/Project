package unsw.dungeon.domain;

import java.util.Timer;
import java.util.TimerTask;

public class GHostPotion extends Entity{
    /**
     * Create an entity positioned in square (x,y)
     *
     * @param x
     * @param y
     */
    public GHostPotion(int x, int y) {
        super(x, y);
    }

    private int lastTime = 5;

    public void startTimer() {
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            //two seconds for redundant for start and end timer
            int tmpTime = lastTime -2;
            public void run() {
                if (tmpTime < 0) {
                    timer.cancel();
                }
                tmpTime--;
                lastTime = tmpTime + 2;
//                System.out.println("last" + ss + "seconds");
            }
        }, 0, 1000);
    }

    public int getLastTime() {
        return lastTime;
    }

    public void setLastTime(int lastTime) {
        this.lastTime = lastTime;
    }

}
