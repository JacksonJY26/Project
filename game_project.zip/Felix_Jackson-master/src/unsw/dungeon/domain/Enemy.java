package unsw.dungeon.domain;

import unsw.dungeon.util.DungeonUtil;

import java.util.Objects;

public class Enemy extends Entity {

    /**
     * Create an entity positioned in square (x,y)
     *
     * @param x
     * @param y
     */
    public Enemy(Dungeon dungeon, int x, int y) {
        super(x, y);
        this.dungeon = dungeon;
    }

    private Dungeon dungeon;

    public Dungeon getDungeon() {
        return dungeon;
    }

    public void setDungeon(Dungeon dungeon) {
        this.dungeon = dungeon;
    }

    public void moveAutomatic() {

        if (Objects.nonNull(dungeon.getPlayer().getInvincibility()) && dungeon.getPlayer().getInvincibility().getLastTime() > 0) {
            double tmpDistance = Double.MIN_VALUE;
            String tmpOrient = "";
            if(calculateDistance(getX(), getY()) == 0){
                return;
            }
            if (!DungeonUtil.getNode(getX() - 1, getY(), dungeon).equals("Wall")) {
                if (calculateDistance(getX() - 1, getY()) >= tmpDistance) {
                    tmpOrient = "Left";
                    tmpDistance = calculateDistance(getX() - 1, getY());
                }
            }
            if (!DungeonUtil.getNode(getX() + 1, getY(), dungeon).equals("Wall")) {
                if (calculateDistance(getX() + 1, getY()) >= tmpDistance) {
                    tmpOrient = "Right";
                    tmpDistance = calculateDistance(getX() + 1, getY());
                }
            }
            if (!DungeonUtil.getNode(getX(), getY() - 1, dungeon).equals("Wall")) {
                if (calculateDistance(getX(), getY() - 1) >= tmpDistance) {
                    tmpOrient = "Up";
                    tmpDistance = calculateDistance(getX(), getY() - 1);
                }
            }
            if (!DungeonUtil.getNode(getX(), getY() + 1, dungeon).equals("Wall")) {
                if (calculateDistance(getX(), getY() + 1) >= tmpDistance) {
                    tmpOrient = "Down";
                    tmpDistance = calculateDistance(getX(), getY() + 1);
                }
            }
            moveNextStop(tmpOrient);
        } else {
            double tmpDistance = Double.MAX_VALUE;
            String tmpOrient = "";
            if(calculateDistance(getX(), getY()) == 0){
                return;
            }
            if (!DungeonUtil.getNode(getX() - 1, getY(), dungeon).equals("Wall")) {
                if (calculateDistance(getX() - 1, getY()) < tmpDistance) {
                    tmpOrient = "Left";
                    tmpDistance = calculateDistance(getX() - 1, getY());
                }
            }
            if (!DungeonUtil.getNode(getX() + 1, getY(), dungeon).equals("Wall")) {
                if (calculateDistance(getX() + 1, getY()) < tmpDistance) {
                    tmpOrient = "Right";
                    tmpDistance = calculateDistance(getX() + 1, getY());
                }
            }
            if (!DungeonUtil.getNode(getX(), getY() - 1, dungeon).equals("Wall")) {
                if (calculateDistance(getX(), getY() - 1) < tmpDistance) {
                    tmpOrient = "Up";
                    tmpDistance = calculateDistance(getX(), getY() - 1);
                }
            }
            if (!DungeonUtil.getNode(getX(), getY() + 1, dungeon).equals("Wall")) {
                if (calculateDistance(getX(), getY() + 1) < tmpDistance) {
                    tmpOrient = "Down";
                    tmpDistance = calculateDistance(getX(), getY() + 1);
                }
            }
            moveNextStop(tmpOrient);
        }

    }

    protected void moveNextStop(String tmpOrient) {
        switch (tmpOrient) {
            case "Up":
                y().set(getY() - 1);
                break;
            case "Down":
                y().set(getY() + 1);
                break;
            case "Left":
                x().set(getX() - 1);
                break;
            case "Right":
                x().set(getX() + 1);
                break;
            default:
                break;
        }
    }

    protected double calculateDistance(int x, int y) {
        return Math.pow(dungeon.getPlayer().getX() - x, 2) + Math.pow(dungeon.getPlayer().getY() - y, 2);
    }
}
