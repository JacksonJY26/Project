/**
 *
 */
package unsw.dungeon.domain;

import unsw.dungeon.domain.Entity;
import unsw.dungeon.domain.Player;
import unsw.dungeon.observer.Observer;

import java.util.ArrayList;
import java.util.List;

/**
 * A dungeon in the interactive dungeon player.
 *
 * A dungeon can contain many entities, each occupy a square. More than one
 * entity can occupy the same square.
 *
 * @author Robert Clifton-Everest
 *
 */
public class Dungeon  {

    private int width, height;
    private List<Entity> entities;
    private Player player;
    private Enemy enemy;
    private Hound hound;

    private boolean success;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public Dungeon(int width, int height) {
        this.width = width;
        this.height = height;
        this.entities = new ArrayList<>();
        this.player = null;
        this.enemy = null;
        this.hound = null;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public Enemy getEnemy() {
        return enemy;
    }

    public void setEnemy(Enemy enemy) {
        this.enemy = enemy;
    }

    public Hound getHound() {
        return hound;
    }

    public void setHound(Hound hound) {
        this.hound = hound;
    }

    public void addEntity(Entity entity) {
        entities.add(entity);
    }

    public List<Entity> getEntities(){
        return entities;
    }

    public void setEntities(List<Entity> entities) {
        this.entities = entities;
    }

}
