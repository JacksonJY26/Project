package unsw.dungeon.domain;

public class Boulder extends Entity {
    /**
     * Create an entity positioned in square (x,y)
     *
     * @param x
     * @param y
     */
    public Boulder(int x, int y) {
        super(x, y);
    }

}
