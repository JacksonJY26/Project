package unsw.dungeon.goal;

public interface SubGoal {

    boolean subGoal();

}
