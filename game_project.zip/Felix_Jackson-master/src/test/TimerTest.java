package test;
import unsw.dungeon.util.DungeonTimer;

public class TimerTest {


    public static void main(String[] args) {
        DungeonTimer.timer(10);
    }
}
