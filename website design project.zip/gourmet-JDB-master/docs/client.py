from inventory_stock import Inventory
from order import Order
from Main import Main
from customer import Customer
from system import OrderSystem

sys = OrderSystem()

